import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load the dataset
df = pd.read_csv('financial_data.csv')

# Define input and output parameters
input_params = ['Age', 'Income', 'Savings_Goal', 'Risk_Tolerance', 'Financial_Plan_Type', 'Monthly_Savings', 'Has_Debt', 'Debt_Amount', 'Debt_Interest_Rate', 'Debt_Repayment_Plan']
output_params = ['Recommended_Investment', 'Eligible_for_Scheme', 'Scheme_Name', 'Scheme_Benefit']

# Select only the relevant columns
df = df[input_params + output_params]

# Encode categorical variables
label_encoders = {}
for column in df.select_dtypes(include=['object']).columns:
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    label_encoders[column] = le

# Split the data into training and testing sets
X = df[input_params]
y = df[output_params]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a RandomForest model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Save the trained model and label encoders
joblib.dump(model, 'financial_advisor_model.pkl')
joblib.dump(label_encoders, 'label_encoders.pkl')
