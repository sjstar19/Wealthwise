import streamlit as st
import joblib
import pandas as pd
import plotly.express as px
import sqlite3
import hashlib
import json
from datetime import datetime
from transformers import BlenderbotTokenizer, BlenderbotForConditionalGeneration
st.set_page_config(page_title="AI Financial Advisor", layout="wide")
# Custom CSS for styling
def set_custom_styles():
    st.markdown(
        """
        <style>
        body {
            background-color: #f4f4f9;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #30475e;
        }
        .stButton>button {
            background-color: #f05454;
            color: white;
            font-weight: bold;
            border-radius: 12px;
            padding: 0.5em 1em;
            transition: background-color 0.3s ease;
        }
        .stButton>button:hover {
            background-color: #d94343;
        }
        .stTextInput>div>input {
            border-radius: 8px;
            padding: 0.75em;
            background-color: #e8f0fe;
            border: 1px solid #c0c4c8;
        }
        </style>
        """, unsafe_allow_html=True
    )

# Initialize database
def init_db():
    conn = sqlite3.connect('financial_advisor.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY, password TEXT, profile JSON)''')
    conn.commit()
    conn.close()

# Hash password
def hash_password(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

# Create user in DB
def create_user(username, password, profile):
    conn = sqlite3.connect('financial_advisor.db')
    c = conn.cursor()
    hashed_pwd = hash_password(password)
    c.execute('INSERT INTO users VALUES (?,?,?)', 
              (username, hashed_pwd, json.dumps(profile)))
    conn.commit()
    conn.close()

# Check if user exists
def check_user(username, password):
    conn = sqlite3.connect('financial_advisor.db')
    c = conn.cursor()
    c.execute('SELECT password FROM users WHERE username=?', (username,))
    stored_pwd = c.fetchone()
    conn.close()
    if stored_pwd:
        return stored_pwd[0] == hash_password(password)
    return False

# Chatbot setup using Blenderbot
def init_chatbot():
    model_name = "facebook/blenderbot-400M-distill"
    tokenizer = BlenderbotTokenizer.from_pretrained(model_name)
    model = BlenderbotForConditionalGeneration.from_pretrained(model_name)
    return tokenizer, model

tokenizer, chatbot_model = init_chatbot()

# Generate response from chatbot
def generate_bot_response(user_message, tokenizer, model):
    inputs = tokenizer([user_message], return_tensors="pt")
    reply_ids = model.generate(**inputs)
    bot_response = tokenizer.decode(reply_ids[0], skip_special_tokens=True)
    return bot_response

# Financial Dashboard
def dashboard(user_input):
    st.header("📈 Financial Dashboard")
    metrics = {
        "Monthly Income": user_input["Income"] / 12,
        "Monthly Savings": user_input["Monthly_Savings"],
        "Savings Rate": (user_input["Monthly_Savings"] / (user_input["Income"] / 12)) * 100,
        "Debt-to-Income Ratio": (user_input["Debt_Amount"] / user_input["Income"]) * 100 if user_input["Has_Debt"] == "Yes" else 0
    }
    cols = st.columns(len(metrics))
    for col, (metric, value) in zip(cols, metrics.items()):
        col.metric(metric, f"${value:,.2f}" if "Ratio" not in metric else f"{value:.1f}%")

    fig_savings = px.pie(
        values=[user_input["Monthly_Savings"], (user_input["Income"]/12) - user_input["Monthly_Savings"]],
        names=["Savings", "Expenses"], title="Monthly Savings vs Expenses",
        color_discrete_sequence=px.colors.sequential.RdBu
    )
    st.plotly_chart(fig_savings)

    if user_input["Has_Debt"] == "Yes":
        fig_debt = px.bar(x=["Total Debt", "Annual Income"], y=[user_input["Debt_Amount"], user_input["Income"]],
                          title="Debt vs Income", color=["Debt", "Income"], text=["Debt", "Income"])
        st.plotly_chart(fig_debt)

# Get user input form
def get_user_input():
    with st.form(key='user_input_form'):
        age = st.slider("What is your age?", 18, 70)
        income = st.slider("What is your annual income?", 15000, 299000)
        savings_goal = st.selectbox("What is your savings goal?", 
                                  ["Business startup", "Child education", "Emergency fund",
                                   "Home renovation", "Legacy planning", "Property down payment",
                                   "Retirement", "Wealth creation", "Vacation", "Wedding"])
        risk_tolerance = st.selectbox("What is your risk tolerance?", ["High", "Low", "Medium"])
        financial_plan_type = st.selectbox("What type of financial plan are you looking for?",
                                         ["Short_term", "Medium_term", "Long_term"])
        monthly_savings = st.slider("How much do you save monthly?", 10000, 100000)
        has_debt = st.selectbox("Do you have any debt?", ["Yes", "No"])
        debt_amount = st.slider("What is the total amount of your debt?", 5000, 9900000) if has_debt == "Yes" else 0
        debt_interest_rate = st.slider("What is the interest rate on your debt?", 5.0, 14.9) if has_debt == "Yes" else 0
        debt_repayment_plan = st.selectbox("What is your debt repayment plan?", 
                                         ["Standard", "Accelerated"]) if has_debt == "Yes" else "None"

        submit_button = st.form_submit_button(label='Submit')

    return {
        "Age": age,
        "Income": income,
        "Savings_Goal": savings_goal,
        "Risk_Tolerance": risk_tolerance,
        "Financial_Plan_Type": financial_plan_type,
        "Monthly_Savings": monthly_savings,
        "Has_Debt": has_debt,
        "Debt_Amount": debt_amount,
        "Debt_Interest_Rate": debt_interest_rate,
        "Debt_Repayment_Plan": debt_repayment_plan
    }, submit_button

class FinancialCalculators:
    @staticmethod
    def emi_calculator(principal, rate, time):
        rate = rate / (12 * 100)
        time = time * 12
        emi = (principal * rate * (1 + rate)**time) / ((1 + rate)**time - 1)
        return emi

    @staticmethod
    def retirement_calculator(current_age, retirement_age, monthly_investment, expected_return, inflation_rate):
        years = retirement_age - current_age
        monthly_rate = expected_return / (12 * 100)
        months = years * 12
        future_value = monthly_investment * ((1 + monthly_rate)**(months) - 1) / monthly_rate
        inflation_adjusted_value = future_value / (1 + inflation_rate/100)**years
        return future_value, inflation_adjusted_value

    @staticmethod
    def sip_calculator(monthly_investment, expected_return, time_years):
        monthly_rate = expected_return / (12 * 100)
        months = time_years * 12
        future_value = monthly_investment * ((1 + monthly_rate)**(months) - 1) / monthly_rate
        total_investment = monthly_investment * months
        returns = future_value - total_investment
        return future_value, total_investment, returns

    @staticmethod
    def tax_calculator(income, regime="old"):
        if regime == "old":
            tax_slabs = [
                (250000, 0), (500000, 5), (1000000, 20), (float('inf'), 30)
            ]
        else:
            tax_slabs = [
                (300000, 0), (600000, 5), (900000, 10), (1200000, 15), (1500000, 20), (float('inf'), 30)
            ]
        tax = 0
        prev_slab = 0
        for slab, rate in tax_slabs:
            if income > prev_slab:
                taxable = min(income - prev_slab, slab - prev_slab)
                tax += taxable * rate / 100
            prev_slab = slab
        return tax

# Portfolio Management
class PortfolioManager:
    def __init__(self):
        self.risk_profiles = {
            "Conservative": {"Equity": 20, "Debt": 60, "Gold": 15, "Cash": 5},
            "Moderate": {"Equity": 50, "Debt": 30, "Gold": 15, "Cash": 5},
            "Aggressive": {"Equity": 70, "Debt": 20, "Gold": 5, "Cash": 5}
        }

    def get_recommendation(self, risk_profile, investment_amount):
        allocation = self.risk_profiles[risk_profile]
        recommendation = {}
        for asset, percentage in allocation.items():
            recommendation[asset] = investment_amount * percentage / 100
        return recommendation

    def generate_portfolio_visualization(self, risk_profile, investment_amount):
        allocation = self.get_recommendation(risk_profile, investment_amount)
        fig = px.pie(
            values=list(allocation.values()),
            names=list(allocation.keys()),
            title=f"Recommended Portfolio Allocation for {risk_profile} Profile"
        )
        return fig


# Contact Us page
def contact_us():
    st.title("📧 Contact Us")
    st.write("We're here to assist you with any queries. Feel free to reach out to us through the form below.")
    with st.form("contact_form"):
        name = st.text_input("Your Name")
        email = st.text_input("Your Email")
        message = st.text_area("Message")
        submit_button = st.form_submit_button("Submit")
        if submit_button:
            st.success(f"Thank you {name}, we will reach out to you at {email} soon!")

# Main function
def main():
    set_custom_styles()


    # Sidebar navigation
    st.sidebar.title("Navigation")
    menu_options = ["Dashboard", "Financial Planning", "Chatbot", "Contact Us", "Settings"]
    choice = st.sidebar.selectbox("Menu", menu_options)

    if choice == "Dashboard":
        st.subheader("Your Financial Dashboard")
        user_input, submit_button = get_user_input()
        if submit_button:
            dashboard(user_input)

    elif choice == "Financial Planning":
                st.subheader("Let's plan your financial future")
                st.subheader("Financial Planning Tools")

        # Financial calculators
    calc_option = st.selectbox("Choose a financial calculator", 
                                ["EMI Calculator", "Retirement Calculator", "SIP Calculator", "Tax Calculator"])
        
    if calc_option == "EMI Calculator":
            principal = st.number_input("Loan Principal Amount", min_value=1000, value=100000)
            rate = st.number_input("Annual Interest Rate (%)", min_value=0.1, value=7.5)
            time = st.number_input("Loan Tenure (years)", min_value=1, value=10)
            if st.button("Calculate EMI"):
                emi = FinancialCalculators.emi_calculator(principal, rate, time)
                st.success(f"Your monthly EMI is ₹{emi:,.2f}")

    elif calc_option == "Retirement Calculator":
            current_age = st.number_input("Current Age", min_value=18, value=30)
            retirement_age = st.number_input("Retirement Age", min_value=40, value=60)
            monthly_investment = st.number_input("Monthly Investment Amount", min_value=500, value=5000)
            expected_return = st.number_input("Expected Annual Return (%)", min_value=1.0, value=7.0)
            inflation_rate = st.number_input("Expected Inflation Rate (%)", min_value=1.0, value=6.0)
            if st.button("Calculate Retirement Savings"):
                future_value, inflation_adjusted_value = FinancialCalculators.retirement_calculator(current_age, retirement_age, monthly_investment, expected_return, inflation_rate)
                st.success(f"Future Value of your investment: ₹{future_value:,.2f}")
                st.info(f"Inflation-adjusted Value: ₹{inflation_adjusted_value:,.2f}")

    elif calc_option == "SIP Calculator":
            monthly_investment = st.number_input("Monthly Investment Amount", min_value=500, value=5000)
            expected_return = st.number_input("Expected Annual Return (%)", min_value=1.0, value=12.0)
            time_years = st.number_input("Investment Duration (years)", min_value=1, value=10)
            if st.button("Calculate SIP"):
                future_value, total_investment, returns = FinancialCalculators.sip_calculator(monthly_investment, expected_return, time_years)
                st.success(f"Future Value of SIP: ₹{future_value:,.2f}")
                st.info(f"Total Investment: ₹{total_investment:,.2f}, Returns: ₹{returns:,.2f}")

    elif calc_option == "Tax Calculator":
            income = st.number_input("Annual Income", min_value=250000, value=1000000)
            regime = st.selectbox("Tax Regime", ["old", "new"])
            if st.button("Calculate Tax"):
                tax = FinancialCalculators.tax_calculator(income, regime)
                st.success(f"Your calculated tax is ₹{tax:,.2f}")

        # Portfolio Management
    st.subheader("Portfolio Management")
    risk_profile = st.selectbox("Select your risk profile", ["Conservative", "Moderate", "Aggressive"])
    investment_amount = st.number_input("Enter your investment amount", min_value=10000, value=100000)
    portfolio_manager = PortfolioManager()
        
    if st.button("Generate Portfolio Recommendation"):
            recommendation = portfolio_manager.get_recommendation(risk_profile, investment_amount)
            st.write("Recommended Allocation:")
            for asset, amount in recommendation.items():
                st.write(f"{asset}: ₹{amount:,.2f}")
            
            st.plotly_chart(portfolio_manager.generate_portfolio_visualization(risk_profile, investment_amount))

            pass

    elif choice == "Chatbot":
        st.subheader("Talk to our Financial Chatbot")
        user_message = st.text_input("You: ")
        if user_message:
            chat_response = generate_bot_response(user_message, tokenizer, chatbot_model)
            st.text(f"Bot: {chat_response}")

    elif choice == "Contact Us":
        contact_us()

    elif choice == "Settings":
     st.subheader("User Profile")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
                if check_user(username, password):
                    st.success(f"Welcome back, {username}")
                    st.session_state.authenticated = True
                else:
                    st.error("Invalid credentials")

if __name__ == '__main__':
    init_db()
    main()
