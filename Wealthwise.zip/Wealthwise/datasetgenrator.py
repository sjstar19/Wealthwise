import pandas as pd
import random



# Define possible government schemes and their benefits
central_government_schemes = {
    "PMAY": "Housing for All",
    "Mudra Loan": "Financial support for small businesses",
    "Atal Pension Yojana": "Pension scheme for unorganized sector workers",
    "Jan Dhan Yojana": "Financial inclusion and banking services",
    "PM-Kisan": "Direct income support to farmers",
    "Sukanya Samriddhi Yojana": "Savings scheme for girl children",
    "National Pension Scheme (NPS)": "Retirement savings scheme",
    "Equity Linked Savings Scheme (ELSS)": "Tax-saving mutual funds",
    "Digital India Initiative": "Promotes digital literacy and access"
}

state_government_schemes = {
    "Maharashtra": [
        ("Maharashtra Chief Minister's Relief Fund", "Financial assistance during disasters"),
        ("MHADA Schemes", "Affordable housing initiatives"),
        ("Maharashtra Farmers' Welfare Scheme", "Financial aid for farmers"),
        ("Maharashtra State Rural Livelihoods Mission", "Skill development and employment generation")
    ],
    "Tamil Nadu": [
        ("Tamil Nadu Chief Minister's Comprehensive Health Insurance Scheme", "Health coverage for low-income families"),
        ("Tamil Nadu Housing Board Schemes", "Affordable housing options"),
        ("Tamil Nadu Women’s Development Corporation", "Financial support for women entrepreneurs"),
        ("Tamil Nadu Skill Development Corporation", "Skill training programs")
    ],
    "Uttar Pradesh": [
        ("Uttar Pradesh Kanya Vidya Dhan Yojana", "Financial assistance for girls' education"),
        ("Uttar Pradesh Mukhyamantri Samagra Awas Yojana", "Housing for all initiative"),
        ("Uttar Pradesh Farmer Loan Waiver Scheme", "Debt relief for farmers"),
        ("Uttar Pradesh Skill Development Mission", "Skill training and employment opportunities")
    ],
}

# Define investment advice categories with detailed advice
investment_advice_categories = {
    "Stocks": [
        "Invest in diversified index funds to spread risk.",
        "Consider blue-chip stocks for stability and dividends.",
        "Research emerging markets for higher growth potential."
    ],
    "Bonds": [
        "Look into government bonds for safety and fixed returns.",
        "Consider corporate bonds with higher yields but assess credit risk.",
        "Diversify bond investments across sectors to mitigate risks."
    ],
    "Real Estate": [
        "Invest in rental properties to generate passive income.",
        "Research REITs (Real Estate Investment Trusts) as an alternative.",
        "Consider location trends and property appreciation potential."
    ],
    "Gold": [
        "Use gold ETFs for easy trading without physical storage.",
        "Consider physical gold as a hedge against inflation.",
        "Research historical gold prices before making large investments."
    ],
    "Mutual Funds": [
        "Choose mutual funds based on your risk profile and goals.",
        "Consider SIPs (Systematic Investment Plans) to average out costs.",
        "Review fund performance regularly to ensure alignment with goals."
    ]
}

# Expanded demographic options
age_brackets = {
    "18-25": {"income_range": (15000, 40000), "risk_profile": ["High", "Moderate"]},
    "26-35": {"income_range": (30000, 80000), "risk_profile": ["High", "Moderate", "Low"]},
    "36-45": {"income_range": (50000, 150000), "risk_profile": ["Moderate", "Low"]},
    "46-60": {"income_range": (80000, 300000), "risk_profile": ["Low", "Very Low"]},
    "60+": {"income_range": (30000, 200000), "risk_profile": ["Very Low"]}
}

# Expanded investment options
investment_instruments = {
    "Equity": {
        "High": ["Small-cap funds", "Mid-cap funds", "Sectoral funds"],
        "Moderate": ["Large-cap funds", "Index funds", "Balanced funds"],
        "Low": ["Blue-chip stocks", "Dividend yield funds"],
        "Very Low": ["Equity-linked saving schemes"]
    },
    "Debt": {
        "High": ["Corporate bonds", "Credit risk funds"],
        "Moderate": ["Government securities", "Banking PSU funds"],
        "Low": ["Fixed deposits", "Post office schemes"],
        "Very Low": ["Senior citizen savings scheme"]
    },
    "Hybrid": {
        "High": ["Aggressive hybrid funds", "Multi-asset funds"],
        "Moderate": ["Balanced advantage funds", "Dynamic asset allocation funds"],
        "Low": ["Conservative hybrid funds", "Monthly income plans"],
        "Very Low": ["Arbitrage funds"]
    }
}

# Financial goals
financial_goals = {
    "Short_term": ["Emergency fund", "Vacation", "Wedding", "Home renovation"],
    "Medium_term": ["Child education", "Business startup", "Property down payment"],
    "Long_term": ["Retirement", "Legacy planning", "Wealth creation"]
}

# Function to generate synthetic financial data
def generate_enhanced_data(num_rows):
    synthetic_data = []

    # Define possible values for advice
    education_advice_options = [
        "Attend financial literacy workshops",
        "Read books on personal finance",
        "Join online courses about investments",
        "Consult with a financial advisor"
    ]

    for _ in range(num_rows):
        # Choose age bracket
        age_bracket = random.choice(list(age_brackets.keys()))
        age = random.randint(int(age_bracket.split('-')[0]), int(age_bracket.split('-')[-1])) if '-' in age_bracket else random.randint(60, 70)

        # Set income and risk tolerance based on age bracket
        income = random.uniform(*age_brackets[age_bracket]["income_range"])
        risk_tolerance = random.choice(age_brackets[age_bracket]["risk_profile"])

        # Select investment instruments based on risk tolerance
        investment_type = random.choice(list(investment_instruments.keys()))
        recommended_investment = random.choice(investment_instruments[investment_type][risk_tolerance])

        # Select a financial goal based on the planning timeframe
        financial_plan_type = random.choice(list(financial_goals.keys()))
        savings_goal = random.choice(financial_goals[financial_plan_type])

        region = random.choice(['Urban', 'Semi-Urban', 'Rural'])
        education_level = random.choice(['No formal education', 'Primary', 'Secondary', 'Graduate', 'Postgraduate'])
        occupation = random.choice(['Salaried', 'Self-Employed', 'Unemployed', 'Business Owner', 'Retired'])
        monthly_savings = random.uniform(10000, 100000)
        eligible_for_scheme = random.choice(['Yes', 'No'])

        # Randomly select a central or state scheme
        if eligible_for_scheme == 'Yes':
            if random.choice([True, False]):
                scheme_name = random.choice(list(central_government_schemes.keys()))
                scheme_benefit = central_government_schemes[scheme_name]
            else:
                state_name = random.choice(list(state_government_schemes.keys()))
                scheme_info = random.choice(state_government_schemes[state_name])
                scheme_name, scheme_benefit = scheme_info[0], scheme_info[1]
                scheme_benefit += f" (State: {state_name})"
        else:
            scheme_name, scheme_benefit = None, None

        # Randomly select debt management details
        has_debt = random.choice(['Yes', 'No'])
        debt_type = random.choice(['Home Loan', 'Educational Loan', 'Personal Loan']) if has_debt == 'Yes' else None
        debt_amount = random.uniform(0, 1000000) if has_debt == 'Yes' else 0
        debt_interest_rate = random.uniform(5, 15) if has_debt == 'Yes' else 0
        debt_repayment_plan = random.choice(['Accelerated', 'Standard']) if has_debt == 'Yes' else None

        # Append the generated row to the synthetic data list
        synthetic_data.append([
            age, income, region, education_level, occupation, savings_goal,
            risk_tolerance, financial_plan_type, monthly_savings, recommended_investment,
            eligible_for_scheme, scheme_name, scheme_benefit, has_debt, debt_type,
            debt_amount, debt_interest_rate, debt_repayment_plan
        ])

    # Create DataFrame for synthetic data
    columns = [
        "Age", "Income", "Region", "Education_Level", "Occupation", "Savings_Goal",
        "Risk_Tolerance", "Financial_Plan_Type", "Monthly_Savings", "Recommended_Investment",
        "Eligible_for_Scheme", "Scheme_Name", "Scheme_Benefit", "Has_Debt", "Debt_Type",
        "Debt_Amount", "Debt_Interest_Rate", "Debt_Repayment_Plan"
    ]
    synthetic_df = pd.DataFrame(synthetic_data, columns=columns)
    return synthetic_df

# Generate additional data (e.g., 1000 rows)
additional_data_df = generate_enhanced_data(1000)

# Save the combined dataset to a new CSV file
additional_data_df.to_csv('enhanced_financial_dataset.csv', index=False)

