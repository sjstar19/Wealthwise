import streamlit as st
import joblib
import pandas as pd

# Load the trained model and label encoders
model = joblib.load('financial_advisor_model.pkl')
label_encoders = joblib.load('label_encoders.pkl')

def get_user_input():
    with st.form(key='user_input_form'):
        age = st.slider("What is your age?", 18, 70)
        income = st.slider("What is your monthly income?", 15000, 299000)
        savings_goal = st.selectbox("What is your savings goal?", ["Business startup", "Child education", "Emergency fund", "Home renovation", "Legacy planning", "Property down payment", "Retirement", "Wealth creation", "Vacation", "Wedding"])
        risk_tolerance = st.selectbox("What is your risk tolerance?", ["High", "Low", "Medium"])
        financial_plan_type = st.selectbox("What type of financial plan are you looking for?", ["Short_term", "Medium_term", "Long_term"])
        monthly_savings = st.slider("How much do you save monthly?", 10000, 100000)
        has_debt = st.selectbox("Do you have any debt?", ["Yes", "No"])
        debt_amount = st.slider("What is the total amount of your debt?", 5000, 9900000)
        debt_interest_rate = st.slider("What is the interest rate on your debt?", 5.0, 14.9)
        debt_repayment_plan = st.selectbox("What is your debt repayment plan?", ["Standard", "Accelerated"])

        submit_button = st.form_submit_button(label='Submit')

    user_input = {
        "Age": age,
        "Income": income,
        "Savings_Goal": savings_goal,
        "Risk_Tolerance": risk_tolerance,
        "Financial_Plan_Type": financial_plan_type,
        "Monthly_Savings": monthly_savings,
        "Has_Debt": has_debt,
        "Debt_Amount": debt_amount,
        "Debt_Interest_Rate": debt_interest_rate,
        "Debt_Repayment_Plan": debt_repayment_plan
    }

    return user_input, submit_button

def preprocess_user_input(user_input):
    for param in user_input:
        if param in label_encoders:
            user_input[param] = label_encoders[param].transform([user_input[param]])[0]
        else:
            user_input[param] = float(user_input[param])
    
    return pd.DataFrame([user_input])

def main():
    st.title("📊 AI Financial Advisor")
    st.markdown("""
    <style>
    .main {
        background-color: #f0f2f6;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border-radius: 12px;
        padding: 10px 24px;
        font-size: 16px;
    }
    .stTextInput>div>div>input {
        border: 2px solid #4CAF50;
        border-radius: 12px;
        padding: 10px;
    }
    </style>
    """, unsafe_allow_html=True)

    st.write("This AI Financial Advisor will ask you a series of questions to understand your financial profile and provide personalized financial advice.")

    user_input, submit_button = get_user_input()

    if submit_button:
        if all(user_input.values()):
            st.write("Your responses:", user_input)

            preprocessed_input = preprocess_user_input(user_input)
            
            prediction = model.predict(preprocessed_input)
            
            recommended_investment = label_encoders['Recommended_Investment'].inverse_transform([prediction[0][0]])[0]
            eligible_for_scheme = label_encoders['Eligible_for_Scheme'].inverse_transform([prediction[0][1]])[0]
            scheme_name = label_encoders['Scheme_Name'].inverse_transform([prediction[0][2]])[0]
            scheme_benefit = label_encoders['Scheme_Benefit'].inverse_transform([prediction[0][3]])[0]

            st.success("Recommended Investment: {}".format(recommended_investment))
            st.success("Eligible for Scheme: {}".format(eligible_for_scheme))
            st.success("Scheme Name: {}".format(scheme_name))
            st.success("Scheme Benefit: {}".format(scheme_benefit))
        else:
            st.error("Please answer all the questions.")

if __name__ == "__main__":
    main()
